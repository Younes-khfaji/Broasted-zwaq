window.onload = function() {
  // عرض نافذة المنبثقة عند تحميل الصفحة
  document.getElementById("welcome-popup").style.display = "flex";
};